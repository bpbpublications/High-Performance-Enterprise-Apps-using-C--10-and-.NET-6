﻿using System;
using System.Collections.Generic;
using System.Linq;

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;

namespace Benchmarking_Ex
{
    public class TestClass
    {
        private readonly List<string> lstMain = new List<string>();
        private readonly int intListSize = 1000000;
        private readonly string strItem = "Test";

        public TestClass()
        {
            //Add a large amount of items to list 
            Enumerable.Range(1, intListSize).ToList().ForEach(x => lstMain.Add(x.ToString()));
            //Insert 'Test' right in the middle. 
            lstMain.Insert(intListSize / 2, strItem);
        }

        [Benchmark]
        public string SingleItem() => lstMain.SingleOrDefault(x => x == strItem);

        [Benchmark]
        public string FirstItem() => lstMain.FirstOrDefault(x => x == strItem);
    }
}
