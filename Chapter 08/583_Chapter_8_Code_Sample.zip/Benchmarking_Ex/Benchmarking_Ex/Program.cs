﻿using BenchmarkDotNet.Running;
using System;

namespace Benchmarking_Ex
{
    public class Program
    {

        static void Main(string[] args)
        {
            var summary = BenchmarkRunner.Run<TestClass>();
            Console.ReadLine();
        }
    }
}
