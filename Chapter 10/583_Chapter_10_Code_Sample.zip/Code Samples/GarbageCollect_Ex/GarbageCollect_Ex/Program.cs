﻿using System;
using System.Runtime;

namespace GarbageCollect_Ex
{
    class Program
    {
        private const int iLimit = 11000;
        static void Main(string[] args)
        {
            Generate();

            Console.WriteLine("Before: {0:N0}", GC.GetTotalMemory(false));

            GCSettings.LargeObjectHeapCompactionMode = GCLargeObjectHeapCompactionMode.CompactOnce;

            GC.Collect();

            Console.WriteLine("After: {0:N0}", GC.GetTotalMemory(true));

            Console.ReadLine();
        }

        static void Generate()
        {
            Version vUnusedObjects;

            for (int i = 0; i < iLimit; i++)
            {
                vUnusedObjects = new Version();
            }
        }
    }
}
