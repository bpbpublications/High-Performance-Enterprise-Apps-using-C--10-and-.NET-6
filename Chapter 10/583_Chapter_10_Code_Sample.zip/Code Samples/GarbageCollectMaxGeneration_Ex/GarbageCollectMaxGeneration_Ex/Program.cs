﻿using System;

namespace GarbageCollectMaxGeneration_Ex
{
    class Program
    {
        private const long iLimit = 11000;
        static void Main()
        {
            Program objGenNumber = new Program();

            Console.WriteLine("Maximum Number of Iterations Supported: {0}", GC.MaxGeneration);

            Program.Generate();

            Console.WriteLine("Determine Current Collection: {0}", GC.GetGeneration(objGenNumber));

            Console.WriteLine("Total Memory: {0}", GC.GetTotalMemory(false));

            GC.Collect(0);

            Console.WriteLine("Current Generation: {0}", GC.GetGeneration(objGenNumber));

            Console.WriteLine("Total Memory: {0}", GC.GetTotalMemory(false));

            GC.Collect(2);

            Console.WriteLine("Generation: {0}", GC.GetGeneration(objGenNumber));
            Console.WriteLine("Total Memory: {0}", GC.GetTotalMemory(false));
            Console.Read();
        }

       static void Generate()
        {
            Version vUnusedObjects;

            for (int i = 0; i < iLimit; i++)
            {
                // Create objects and release them to fill up memory
                // with unused objects.
                vUnusedObjects = new Version();
            }
        }
    }
}