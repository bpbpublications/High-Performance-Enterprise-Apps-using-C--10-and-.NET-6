﻿using System;
using System.Runtime.Caching;

namespace InMemoryCache_Ex
{
    class Program
    {
        static void Main(string[] args)
        {
            ObjectCache oCache = MemoryCache.Default;

            oCache.Add("FirstCache", " FirstValue", null);
            oCache.Add("SecondCache", 2, null);

            var cipPolicy = new CacheItemPolicy
            {
                AbsoluteExpiration = DateTimeOffset.Now.AddSeconds(90.0),

            };

            oCache.Add("ThirdCache", "Lives in Memory for 90 Seconds", cipPolicy);

            var cItem = new CacheItem("FourthCache", " Fourthvalue");
            oCache.Add(cItem, cipPolicy);

            Console.WriteLine("FourthCache - " + oCache.Get("FourthCache"));

            oCache.Remove("FirstCache");

            oCache.Set("SecondCache", 20, null);

            Print(oCache);
        }

        public static void Print(ObjectCache oCache)
        {
            foreach (var c in oCache)
            {
                Console.WriteLine("Cache Key and Value:" + c.Key + " - " + c.Value);
            }
            Console.ReadLine();
        }
    }
}