﻿using System;

namespace Pattern_Ex
{
    class Program
    {
        static void Main(string[] args)
        {
            char c = 't';
            if ((c is (>= 'a' and <= 'z') or (>= 'A' and <= 'Z')))
                Console.WriteLine("Alphabetical Letter");


        }
    }
}
